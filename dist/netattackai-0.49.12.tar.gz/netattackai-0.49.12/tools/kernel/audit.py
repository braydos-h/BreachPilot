"""Audit-log helpers — credential redaction + audit decorators.

Extracted from ``tools.mcp_shared`` (Phase 2 kernel). ``tools.mcp_shared``
re-exports for backwards compat; ``tools.mcp_tools.registry`` re-imports
from there.

Ponytail: pure redaction + thin decorator factories. No behavior change —
verbatim move of ``_redact_*``, ``_mask_secret_content``, ``_audit_log``,
``_result_is_blocked``, ``_extract_audit_target``, ``make_audit_tool``,
``make_require_allowlist``.
"""

from __future__ import annotations

import functools
import inspect
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from tools.kernel.allowlist import (
    _check_allowlist,
    _extract_msf_rhosts,
)

_SECRET_ARG_NAMES = frozenset(
    {
        "password",
        "passwd",
        "pass",
        "passphrase",
        "secret",
        "shared_secret",
        "pre_shared_key",
        "secret_key",
        "signing_key",
        "ntlm_hash",
        "ntlm",
        "hash",
        "kerberos_ticket",
        "asrep_key",
        "rc4_key",
        "aes_key",
        "token",
        "auth_token",
        "access_token",
        "refresh_token",
        "session_key",
        "cookies",
        "authorization",
        "api_key",
        "apikey",
        "credential",
        "credentials",
        "creds",
        "private_key",
        "priv_key",
    }
)

_REDACTED = "***REDACTED***"

_MASK_URL_AUTH_RE = re.compile(r"(?<=://)[^@\s:/]+:[^@\s:/]+(?=@)", re.IGNORECASE)
_MASK_U_FLAG_RE = re.compile(
    r"((?<![\w-])(?:-u|--user)\s+)[^\s:]+:[^\s]+",
    re.IGNORECASE,
)
_MASK_LONG_PW_RE = re.compile(
    r"((?<![\w-])(?:--password|--passwd|--passphrase|--pass|--pwd|-pass)\s+)[^\s]+",
    re.IGNORECASE,
)
_MASK_HYDRA_P_RE = re.compile(
    r"(\b(?:hydra|medusa|crackmapexec|netexec|cme|evil-winrm)\b[^\n]*?(?<![\w-])-p\s+)[^\s]+",
    re.IGNORECASE,
)
_MASK_MSF_SET_RE = re.compile(
    r"(\bset\s+(?:SMBPass|PASSWORD|PASSWD|DbUserPass|DbPassword|DbPass|SECRET|SECRETKEY|"
    r"SECRET_KEY|TOKEN|API_KEY|APIKEY|NTLM_HASH|PRIVATE_KEY|PRIV_KEY|ACCESS_KEY|"
    r"AUTH_TOKEN|CREDENTIAL|DB_PASSWORD|DBPASS)\s+)[^\s]+",
    re.IGNORECASE,
)
_MASK_HASHES_RE = re.compile(
    r"((?<![\w-])-hashes\s+)(?:[\da-fA-F]{16,}:[\da-fA-F]{16,}|:[\da-fA-F]{16,}|[\da-fA-F]{16,})",
    re.IGNORECASE,
)
_MASK_NTLM_FLAG_RE = re.compile(
    r"((?<![\w-])-ntlm\s+)[\da-fA-F]{16,}",
    re.IGNORECASE,
)
_MASK_KV_SECRET_RE = re.compile(
    r"\b((?:SMBPass|PASSWORD|PASSWD|DbUserPass|DbPassword|DbPass|SECRETKEY|SECRET_KEY|"
    r"SECRET|TOKEN|API_KEY|APIKEY|NTLM_HASH|PRIVATE_KEY|PRIV_KEY|ACCESS_KEY|"
    r"AUTH_TOKEN|CREDENTIAL|CREDENTIALS|DB_PASSWORD|DBPASS)\s*=\s*)"
    r"[^\s,;=.\[\(\$\{]+",
    re.IGNORECASE,
)
_MASK_AUTH_HDR_RE = re.compile(
    r"(Authorization\s*:\s*(?:Basic|Bearer|Digest|Negotiate|NTLM)\s+)[^\s,;'\"]+",
    re.IGNORECASE,
)
_MASK_PY_AUTH_TUPLE_RE = re.compile(
    r"(\bauth\s*=\s*\(\s*)[\"'][^\"']+[\"']\s*,\s*[\"'][^\"']+[\"'](\s*\))",
    re.IGNORECASE,
)

_MASK_RES = (
    _MASK_URL_AUTH_RE,
    _MASK_U_FLAG_RE,
    _MASK_LONG_PW_RE,
    _MASK_HYDRA_P_RE,
    _MASK_MSF_SET_RE,
    _MASK_HASHES_RE,
    _MASK_NTLM_FLAG_RE,
    _MASK_KV_SECRET_RE,
    _MASK_AUTH_HDR_RE,
    _MASK_PY_AUTH_TUPLE_RE,
)

_WHOLESALE_REDACT_FIELDS = frozenset({"input_text", "notes"})


def _mask_secret_content(value: Any) -> Any:
    if not isinstance(value, str) or not value:
        return value
    out = value
    for rx in _MASK_RES:
        if rx is _MASK_URL_AUTH_RE:
            out = rx.sub(_REDACTED, out)
        elif rx is _MASK_PY_AUTH_TUPLE_RE:
            out = rx.sub(rf"\1{_REDACTED}\2", out)
        else:
            out = rx.sub(rf"\1{_REDACTED}", out)
    return out


def _redact_nested(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            k: (_REDACTED if isinstance(k, str) and k.lower() in _SECRET_ARG_NAMES else _redact_nested(v))
            for k, v in value.items()
        }
    if isinstance(value, str):
        return _mask_secret_content(value)
    return value


def _redact_args(args: dict[str, Any] | None) -> dict[str, Any]:
    if not args:
        return {}
    redacted: dict[str, Any] = {}
    for name, value in args.items():
        lname = name.lower() if isinstance(name, str) else ""
        if lname in _SECRET_ARG_NAMES:
            redacted[name] = _REDACTED
        elif lname in _WHOLESALE_REDACT_FIELDS and value:
            redacted[name] = _REDACTED
        elif isinstance(value, str):
            redacted[name] = _mask_secret_content(value)
        else:
            redacted[name] = _redact_nested(value)
    return redacted


def _audit_log(
    audit_path: Path,
    *,
    target_ip: str,
    tool_name: str,
    approved: bool,
    status: str,
    command: str = "",
    args: dict[str, Any] | None = None,
    attempt_id: str = "",
    code_sha256: str = "",
    duration_seconds: float = 0.0,
) -> None:
    import json as _json

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "target_ip": target_ip,
        "tool_name": tool_name,
        "approved": approved,
        "status": status,
        "command": _mask_secret_content(command) if command else "",
        "args": args or {},
        "attempt_id": attempt_id,
        "code_sha256": code_sha256,
        "duration_seconds": duration_seconds,
    }
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("a", encoding="utf-8") as handle:
        handle.write(_json.dumps(record, default=str) + "\n")


_BLOCKED_RESULT_MARKERS = ("BLOCKED:", "TERMINAL_RESULT: BLOCKED", "ROOT_CMD_RESULT:", "ERROR:")


def _result_is_blocked(result: Any) -> bool:
    try:
        text = str(result).lstrip().upper()
    except Exception:
        return False
    return text.startswith(_BLOCKED_RESULT_MARKERS)


def _extract_audit_target(bound: "inspect.BoundArguments") -> str:
    args = bound.arguments
    hosts: list[str] = []
    for key in ("command", "script_content"):
        text = args.get(key)
        if isinstance(text, str) and text:
            hosts.extend(_extract_msf_rhosts(text))
    lhost = args.get("lhost")
    if isinstance(lhost, str) and lhost:
        hosts.append(lhost)
    seen: set[str] = set()
    cleaned: list[str] = []
    for h in hosts:
        v = h.strip().strip('"').strip("'")
        if v and v not in seen:
            seen.add(v)
            cleaned.append(v)
    return ",".join(cleaned)


def make_require_allowlist(workspace: Path, config: dict[str, Any] | None):
    def require_allowlist(target_param: str = "target_ip", *, audit: bool = True):
        def decorator(fn):
            sig = inspect.signature(fn)
            if inspect.iscoroutinefunction(fn):

                @functools.wraps(fn)
                async def async_wrapper(*args, **kwargs):
                    bound = sig.bind(*args, **kwargs)
                    bound.apply_defaults()
                    target_ip = bound.arguments.get(target_param, "")
                    allowed, reason = _check_allowlist(target_ip, config)
                    if audit:
                        _audit_log(
                            workspace / "exploit_audit.jsonl",
                            target_ip=target_ip,
                            tool_name=fn.__name__,
                            approved=allowed,
                            status="blocked" if not allowed else "started",
                            args=_redact_args(dict(bound.arguments)),
                        )
                    if not allowed:
                        return f"BLOCKED: {reason}\nATTEMPT_ID: preflight\nTOOL: {fn.__name__}\nTARGET: {target_ip}"
                    result = await fn(*args, **kwargs)
                    if audit:
                        blocked = _result_is_blocked(result)
                        _audit_log(
                            workspace / "exploit_audit.jsonl",
                            target_ip=target_ip,
                            tool_name=fn.__name__,
                            approved=not blocked,
                            status="blocked" if blocked else "completed",
                            args=_redact_args(dict(bound.arguments)),
                        )
                    return result

                async_wrapper.__signature__ = sig  # type: ignore[attr-defined]
                async_wrapper.__wrapped_require_allowlist__ = True  # type: ignore[attr-defined]
                async_wrapper.__wrapped_audit_tool__ = bool(audit)  # type: ignore[attr-defined]
                return async_wrapper
            else:

                @functools.wraps(fn)
                def wrapper(*args, **kwargs):
                    bound = sig.bind(*args, **kwargs)
                    bound.apply_defaults()
                    target_ip = bound.arguments.get(target_param, "")
                    allowed, reason = _check_allowlist(target_ip, config)
                    if audit:
                        _audit_log(
                            workspace / "exploit_audit.jsonl",
                            target_ip=target_ip,
                            tool_name=fn.__name__,
                            approved=allowed,
                            status="blocked" if not allowed else "started",
                            args=_redact_args(dict(bound.arguments)),
                        )
                    if not allowed:
                        return f"BLOCKED: {reason}\nATTEMPT_ID: preflight\nTOOL: {fn.__name__}\nTARGET: {target_ip}"
                    result = fn(*args, **kwargs)
                    if audit:
                        blocked = _result_is_blocked(result)
                        _audit_log(
                            workspace / "exploit_audit.jsonl",
                            target_ip=target_ip,
                            tool_name=fn.__name__,
                            approved=not blocked,
                            status="blocked" if blocked else "completed",
                            args=_redact_args(dict(bound.arguments)),
                        )
                    return result

                wrapper.__signature__ = sig  # type: ignore[attr-defined]
                wrapper.__wrapped_require_allowlist__ = True  # type: ignore[attr-defined]
                wrapper.__wrapped_audit_tool__ = bool(audit)  # type: ignore[attr-defined]
                return wrapper

        return decorator

    return require_allowlist


def make_audit_tool(workspace: Path):
    def audit_tool(fn):
        sig = inspect.signature(fn)
        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                target_ip = _extract_audit_target(bound)
                _audit_log(
                    workspace / "exploit_audit.jsonl",
                    target_ip=target_ip,
                    tool_name=fn.__name__,
                    approved=True,
                    status="started",
                    args=_redact_args(dict(bound.arguments)),
                )
                result = await fn(*args, **kwargs)
                blocked = _result_is_blocked(result)
                _audit_log(
                    workspace / "exploit_audit.jsonl",
                    target_ip=target_ip,
                    tool_name=fn.__name__,
                    approved=not blocked,
                    status="blocked" if blocked else "completed",
                    args=_redact_args(dict(bound.arguments)),
                )
                return result

            async_wrapper.__signature__ = sig  # type: ignore[attr-defined]
            async_wrapper.__wrapped_audit_tool__ = True  # type: ignore[attr-defined]
            return async_wrapper
        else:

            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                target_ip = _extract_audit_target(bound)
                _audit_log(
                    workspace / "exploit_audit.jsonl",
                    target_ip=target_ip,
                    tool_name=fn.__name__,
                    approved=True,
                    status="started",
                    args=_redact_args(dict(bound.arguments)),
                )
                result = fn(*args, **kwargs)
                blocked = _result_is_blocked(result)
                _audit_log(
                    workspace / "exploit_audit.jsonl",
                    target_ip=target_ip,
                    tool_name=fn.__name__,
                    approved=not blocked,
                    status="blocked" if blocked else "completed",
                    args=_redact_args(dict(bound.arguments)),
                )
                return result

            wrapper.__signature__ = sig  # type: ignore[attr-defined]
            wrapper.__wrapped_audit_tool__ = True  # type: ignore[attr-defined]
            return wrapper

    return audit_tool
